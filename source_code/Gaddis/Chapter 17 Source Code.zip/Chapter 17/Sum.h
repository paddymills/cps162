#ifndef SUM_H
#define SUM_H

class Sum
{
public:
   int operator()(int a, int b)
   {
      return a + b;
   }
};
#endif